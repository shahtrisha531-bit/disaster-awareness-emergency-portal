<?php

require_once __DIR__ . "/database.php";

echo "<h1>Database Connected Successfully! 🎉</h1>";

?>